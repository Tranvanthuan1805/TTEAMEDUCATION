// Vercel serverless function for courses API
const mysql = require('mysql2/promise');

// Database configuration
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'courseplatform',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  connectTimeout: 60000,
  acquireTimeout: 60000,
  timeout: 60000
};

// Create connection pool
let pool;

async function getPool() {
  if (!pool) {
    pool = mysql.createPool(dbConfig);
  }
  return pool;
}

// Sample courses data (fallback if database is not available)
const sampleCourses = [
  {
    id: 1,
    title: 'JavaScript từ cơ bản đến nâng cao',
    description: 'Học JavaScript từ những kiến thức cơ bản nhất đến các kỹ thuật nâng cao',
    price: 299000,
    originalPrice: 599000,
    category: 'programming',
    level: 'Beginner',
    duration: '40 giờ',
    students: 1250,
    rating: 4.8,
    instructor: 'Nguyễn Văn A',
    image: 'https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?w=400',
    isFree: false,
    lessons: 45,
    tags: ['JavaScript', 'Web Development', 'Programming']
  },
  {
    id: 2,
    title: 'Thiết kế UI/UX chuyên nghiệp',
    description: 'Khóa học thiết kế giao diện và trải nghiệm người dùng từ cơ bản đến chuyên nghiệp',
    price: 0,
    originalPrice: 0,
    category: 'design',
    level: 'Intermediate',
    duration: '30 giờ',
    students: 890,
    rating: 4.9,
    instructor: 'Trần Thị B',
    image: 'https://images.unsplash.com/photo-1558655146-d09347e92766?w=400',
    isFree: true,
    lessons: 35,
    tags: ['UI Design', 'UX Design', 'Figma']
  },
  {
    id: 3,
    title: 'Marketing Digital toàn diện',
    description: 'Chiến lược marketing online hiệu quả cho doanh nghiệp hiện đại',
    price: 399000,
    originalPrice: 799000,
    category: 'marketing',
    level: 'Advanced',
    duration: '25 giờ',
    students: 650,
    rating: 4.7,
    instructor: 'Lê Văn C',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400',
    isFree: false,
    lessons: 28,
    tags: ['Digital Marketing', 'SEO', 'Social Media']
  }
];

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  try {
    const { method, query } = req;
    const { id, category, search, limit = 10, offset = 0 } = query;

    if (method === 'GET') {
      // If requesting specific course by ID
      if (id) {
        try {
          const pool = await getPool();
          const [rows] = await pool.execute('SELECT * FROM courses WHERE id = ?', [id]);
          
          if (rows.length > 0) {
            res.status(200).json({
              success: true,
              data: rows[0]
            });
          } else {
            // Fallback to sample data
            const course = sampleCourses.find(c => c.id == id);
            if (course) {
              res.status(200).json({
                success: true,
                data: course
              });
            } else {
              res.status(404).json({
                success: false,
                message: 'Course not found'
              });
            }
          }
        } catch (dbError) {
          console.log('Database error, using sample data:', dbError.message);
          const course = sampleCourses.find(c => c.id == id);
          if (course) {
            res.status(200).json({
              success: true,
              data: course
            });
          } else {
            res.status(404).json({
              success: false,
              message: 'Course not found'
            });
          }
        }
        return;
      }

      // Get all courses with filtering
      try {
        const pool = await getPool();
        let query = 'SELECT * FROM courses WHERE 1=1';
        let params = [];

        if (category && category !== 'all') {
          if (category === 'free') {
            query += ' AND price = 0';
          } else if (category === 'paid') {
            query += ' AND price > 0';
          } else {
            query += ' AND category = ?';
            params.push(category);
          }
        }

        if (search) {
          query += ' AND (title LIKE ? OR description LIKE ?)';
          params.push(`%${search}%`, `%${search}%`);
        }

        query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
        params.push(parseInt(limit), parseInt(offset));

        const [rows] = await pool.execute(query, params);
        
        res.status(200).json({
          success: true,
          data: rows,
          total: rows.length
        });
      } catch (dbError) {
        console.log('Database error, using sample data:', dbError.message);
        
        // Filter sample data
        let filteredCourses = [...sampleCourses];
        
        if (category && category !== 'all') {
          if (category === 'free') {
            filteredCourses = filteredCourses.filter(course => course.isFree);
          } else if (category === 'paid') {
            filteredCourses = filteredCourses.filter(course => !course.isFree);
          } else {
            filteredCourses = filteredCourses.filter(course => course.category === category);
          }
        }

        if (search) {
          const searchLower = search.toLowerCase();
          filteredCourses = filteredCourses.filter(course => 
            course.title.toLowerCase().includes(searchLower) || 
            course.description.toLowerCase().includes(searchLower)
          );
        }

        // Apply pagination
        const startIndex = parseInt(offset);
        const endIndex = startIndex + parseInt(limit);
        const paginatedCourses = filteredCourses.slice(startIndex, endIndex);

        res.status(200).json({
          success: true,
          data: paginatedCourses,
          total: filteredCourses.length
        });
      }
    } else {
      res.status(405).json({
        success: false,
        message: 'Method not allowed'
      });
    }
  } catch (error) {
    console.error('API Error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
}
