// API Configuration - Vercel Deployment
const API_BASE_URL = window.location.hostname === 'localhost' 
    ? 'http://localhost:3000/api' 
    : '/api'; // For Vercel deployment

// Global Variables
let currentUser = null;
let courses = [];
let blogPosts = [];
let currentPage = 1;
let currentFilter = 'all';

// DOM Elements
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');
const authButtons = document.querySelector('.auth-buttons');

// Initialize App
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Check if user is logged in
    checkAuthStatus();
    
    // Load initial data
    loadCourses();
    loadBlogPosts();
    
    // Setup event listeners
    setupEventListeners();
    
    // Setup scroll animations
    setupScrollAnimations();
    
    // Setup smooth scrolling
    setupSmoothScrolling();
}

// Authentication Functions
function checkAuthStatus() {
    const token = localStorage.getItem('authToken');
    if (token) {
        // Verify token with backend
        verifyToken(token);
    }
}

async function verifyToken(token) {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/verify`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (response.ok) {
            const userData = await response.json();
            currentUser = userData;
            updateAuthUI();
        } else {
            localStorage.removeItem('authToken');
        }
    } catch (error) {
        console.error('Token verification failed:', error);
        localStorage.removeItem('authToken');
    }
}

function updateAuthUI() {
    if (currentUser) {
        authButtons.innerHTML = `
            <div class="user-menu">
                <img src="${currentUser.avatar || '/images/default-avatar.png'}" alt="Avatar" class="user-avatar">
                <span class="user-name">${currentUser.fullName || currentUser.username}</span>
                <div class="dropdown-menu">
                    <a href="#" onclick="showProfile()">Hồ sơ</a>
                    <a href="#" onclick="showMyCourses()">Khóa học của tôi</a>
                    <a href="#" onclick="showDashboard()">Dashboard</a>
                    <a href="#" onclick="logout()">Đăng xuất</a>
                </div>
            </div>
        `;
    }
}

// Navigation Functions
function setupEventListeners() {
    // Mobile menu toggle
    if (hamburger) {
        hamburger.addEventListener('click', () => {
            navMenu.classList.toggle('active');
        });
    }

    // Course filter buttons
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            filterButtons.forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            currentFilter = e.target.dataset.filter;
            filterCourses(currentFilter);
        });
    });

    // Form submissions
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const contactForm = document.getElementById('contactForm');

    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
    
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactForm);
    }

    // Load more buttons
    const loadMoreCourses = document.getElementById('loadMoreCourses');
    const loadMoreBlogs = document.getElementById('loadMoreBlogs');

    if (loadMoreCourses) {
        loadMoreCourses.addEventListener('click', () => {
            currentPage++;
            loadCourses(currentPage);
        });
    }

    if (loadMoreBlogs) {
        loadMoreBlogs.addEventListener('click', () => {
            loadBlogPosts(true);
        });
    }

    // Chatbot input
    const chatbotInput = document.getElementById('chatbotInput');
    if (chatbotInput) {
        chatbotInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }
}

// Data Loading Functions
async function loadCourses(page = 1, append = false) {
    try {
        showLoading();
        const offset = (page - 1) * 6;
        const response = await fetch(`${API_BASE_URL}/courses?limit=6&offset=${offset}`);
        
        if (response.ok) {
            const data = await response.json();
            
            if (data.success) {
                if (append) {
                    courses = [...courses, ...data.data];
                } else {
                    courses = data.data;
                }
                
                renderCourses(courses);
            } else {
                throw new Error(data.message || 'API error');
            }
        } else {
            throw new Error('HTTP error: ' + response.status);
        }
    } catch (error) {
        console.error('Error loading courses:', error);
        showNotification('Lỗi kết nối API: ' + error.message, 'error');
        // Load sample data for demo
        loadSampleCourses();
    } finally {
        hideLoading();
    }
}

async function loadBlogPosts(append = false) {
    try {
        const response = await fetch(`${API_BASE_URL}/blog?limit=6`);
        
        if (response.ok) {
            const data = await response.json();
            
            if (data.success) {
                if (append) {
                    blogPosts = [...blogPosts, ...data.data];
                } else {
                    blogPosts = data.data;
                }
                
                renderBlogPosts(blogPosts);
            } else {
                throw new Error(data.message || 'API error');
            }
        } else {
            throw new Error('HTTP error: ' + response.status);
        }
    } catch (error) {
        console.error('Error loading blog posts:', error);
        showNotification('Lỗi kết nối API: ' + error.message, 'error');
        // Load sample data for demo
        loadSampleBlogPosts();
    }
}

// Sample Data for Demo
function loadSampleCourses() {
    courses = [
        {
            id: 1,
            title: 'JavaScript từ cơ bản đến nâng cao',
            description: 'Học JavaScript từ những kiến thức cơ bản nhất đến các kỹ thuật nâng cao',
            category: 'Lập trình',
            price: 299000,
            is_free: false,
            thumbnail: '',
            instructor_name: 'Nguyễn Văn A',
            total_students: 1250,
            duration: 1200
        },
        {
            id: 2,
            title: 'HTML & CSS Responsive Design',
            description: 'Tạo website responsive đẹp mắt với HTML5 và CSS3',
            category: 'Thiết kế',
            price: 0,
            is_free: true,
            thumbnail: '',
            instructor_name: 'Nguyễn Văn A',
            total_students: 2100,
            duration: 800
        },
        {
            id: 3,
            title: 'React.js cho người mới bắt đầu',
            description: 'Xây dựng ứng dụng web hiện đại với React.js',
            category: 'Lập trình',
            price: 399000,
            is_free: false,
            thumbnail: '',
            instructor_name: 'Nguyễn Văn A',
            total_students: 890,
            duration: 1500
        },
        {
            id: 4,
            title: 'UI/UX Design Fundamentals',
            description: 'Thiết kế giao diện người dùng chuyên nghiệp',
            category: 'Thiết kế',
            price: 0,
            is_free: true,
            thumbnail: '',
            instructor_name: 'Nguyễn Văn A',
            total_students: 1580,
            duration: 1000
        },
        {
            id: 5,
            title: 'Digital Marketing Strategy',
            description: 'Chiến lược marketing số hiệu quả',
            category: 'Marketing',
            price: 199000,
            is_free: false,
            thumbnail: '',
            instructor_name: 'Nguyễn Văn A',
            total_students: 750,
            duration: 900
        },
        {
            id: 6,
            title: 'Python cho Data Science',
            description: 'Phân tích dữ liệu với Python và các thư viện phổ biến',
            category: 'Lập trình',
            price: 0,
            is_free: true,
            thumbnail: '',
            instructor_name: 'Nguyễn Văn A',
            total_students: 1350,
            duration: 1800
        }
    ];
    
    renderCourses(courses);
}

function loadSampleBlogPosts() {
    blogPosts = [
        {
            id: 1,
            title: '10 xu hướng công nghệ nổi bật năm 2024',
            summary: 'Khám phá những xu hướng công nghệ mới nhất sẽ định hình tương lai',
            created_at: '2024-01-15',
            thumbnail: '',
            author_name: 'Nguyễn Văn A'
        },
        {
            id: 2,
            title: 'Cách học lập trình hiệu quả cho người mới bắt đầu',
            summary: 'Hướng dẫn chi tiết cách bắt đầu học lập trình một cách khoa học',
            created_at: '2024-01-10',
            thumbnail: '',
            author_name: 'Trần Thị B'
        },
        {
            id: 3,
            title: 'Thiết kế UI/UX: Từ ý tưởng đến sản phẩm',
            summary: 'Quy trình thiết kế UI/UX chuyên nghiệp từ A đến Z',
            created_at: '2024-01-05',
            thumbnail: '',
            author_name: 'Lê Minh C'
        }
    ];
    
    renderBlogPosts(blogPosts);
}

// Rendering Functions
function renderCourses(coursesToRender) {
    const coursesGrid = document.getElementById('coursesGrid');
    if (!coursesGrid) return;

    coursesGrid.innerHTML = '';
    
    coursesToRender.forEach(course => {
        const courseCard = createCourseCard(course);
        coursesGrid.appendChild(courseCard);
    });
}

function createCourseCard(course) {
    const card = document.createElement('div');
    card.className = 'course-card';
    card.innerHTML = `
        <div class="course-thumbnail">
            <i class="fas fa-play-circle"></i>
        </div>
        <div class="course-content">
            <span class="course-category">${course.category}</span>
            <h3 class="course-title">${course.title}</h3>
            <p class="course-description">${course.description}</p>
            <div class="course-meta">
                <span class="course-price ${course.is_free ? 'free' : ''}">
                    ${course.is_free ? 'Miễn phí' : formatPrice(course.price)}
                </span>
                <div class="course-rating">
                    <div class="stars">
                        ${generateStars(4.5)}
                    </div>
                    <span>(4.5)</span>
                </div>
            </div>
            <div class="course-footer">
                <span class="course-students">
                    <i class="fas fa-users"></i> ${course.total_students || 0} học viên
                </span>
                <button class="enroll-btn" onclick="enrollCourse(${course.id})">
                    ${course.is_free ? 'Học ngay' : 'Đăng ký'}
                </button>
            </div>
        </div>
    `;
    
    return card;
}

function renderBlogPosts(postsToRender) {
    const blogGrid = document.getElementById('blogGrid');
    if (!blogGrid) return;

    blogGrid.innerHTML = '';
    
    postsToRender.forEach(post => {
        const blogCard = createBlogCard(post);
        blogGrid.appendChild(blogCard);
    });
}

function createBlogCard(post) {
    const card = document.createElement('div');
    card.className = 'blog-card';
    card.innerHTML = `
        <div class="blog-thumbnail"></div>
        <div class="blog-content">
            <div class="blog-date">${formatDate(post.created_at)}</div>
            <h3 class="blog-title">${post.title}</h3>
            <p class="blog-excerpt">${post.summary}</p>
            <div class="blog-author">
                <small>Tác giả: ${post.author_name}</small>
            </div>
            <a href="#" class="read-more" onclick="readBlogPost(${post.id})">Đọc tiếp</a>
        </div>
    `;
    
    return card;
}

// Utility Functions
function formatPrice(price) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(price);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('vi-VN');
}

function generateStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    let stars = '';
    
    for (let i = 0; i < fullStars; i++) {
        stars += '<i class="fas fa-star"></i>';
    }
    
    if (hasHalfStar) {
        stars += '<i class="fas fa-star-half-alt"></i>';
    }
    
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
        stars += '<i class="far fa-star"></i>';
    }
    
    return stars;
}

// Filter Functions
function filterCourses(filter) {
    let filteredCourses;
    
    switch (filter) {
        case 'free':
            filteredCourses = courses.filter(course => course.is_free);
            break;
        case 'paid':
            filteredCourses = courses.filter(course => !course.is_free);
            break;
        case 'programming':
            filteredCourses = courses.filter(course => 
                course.category.toLowerCase().includes('lập trình'));
            break;
        case 'design':
            filteredCourses = courses.filter(course => 
                course.category.toLowerCase().includes('thiết kế'));
            break;
        default:
            filteredCourses = courses;
    }
    
    renderCourses(filteredCourses);
}

// Authentication Handlers
async function handleLogin(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const loginData = {
        username: formData.get('username') || e.target.querySelector('input[type="text"]').value,
        password: formData.get('password') || e.target.querySelector('input[type="password"]').value
    };

    try {
        showLoading();
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(loginData)
        });

        if (response.ok) {
            const data = await response.json();
            localStorage.setItem('authToken', data.token);
            currentUser = data.user;
            updateAuthUI();
            closeModal('loginModal');
            showNotification('Đăng nhập thành công!');
        } else {
            const error = await response.json();
            showNotification(error.message || 'Đăng nhập thất bại', 'error');
        }
    } catch (error) {
        console.error('Login error:', error);
        showNotification('Lỗi kết nối', 'error');
    } finally {
        hideLoading();
    }
}

async function handleRegister(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const inputs = e.target.querySelectorAll('input');
    const registerData = {
        fullName: inputs[0].value,
        username: inputs[1].value,
        email: inputs[2].value,
        password: inputs[3].value,
        confirmPassword: inputs[4].value
    };

    // Validate passwords match
    if (registerData.password !== registerData.confirmPassword) {
        showNotification('Mật khẩu xác nhận không khớp', 'error');
        return;
    }

    try {
        showLoading();
        const response = await fetch(`${API_BASE_URL}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(registerData)
        });

        if (response.ok) {
            closeModal('registerModal');
            showNotification('Đăng ký thành công! Vui lòng đăng nhập.');
            openModal('loginModal');
        } else {
            const error = await response.json();
            showNotification(error.message || 'Đăng ký thất bại', 'error');
        }
    } catch (error) {
        console.error('Register error:', error);
        showNotification('Lỗi kết nối', 'error');
    } finally {
        hideLoading();
    }
}

async function handleContactForm(e) {
    e.preventDefault();
    
    const inputs = e.target.querySelectorAll('input, textarea');
    const contactData = {
        name: inputs[0].value,
        email: inputs[1].value,
        subject: inputs[2].value,
        message: inputs[3].value
    };

    try {
        showLoading();
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        showNotification('Tin nhắn đã được gửi thành công!');
        e.target.reset();
    } catch (error) {
        console.error('Contact form error:', error);
        showNotification('Không thể gửi tin nhắn', 'error');
    } finally {
        hideLoading();
    }
}

function logout() {
    localStorage.removeItem('authToken');
    currentUser = null;
    location.reload();
}

// Course Functions
async function enrollCourse(courseId) {
    if (!currentUser) {
        openModal('loginModal');
        return;
    }

    try {
        showLoading();
        const response = await fetch(`${API_BASE_URL}/enrollments`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('authToken')}`
            },
            body: JSON.stringify({ courseId })
        });

        if (response.ok) {
            showNotification('Đăng ký khóa học thành công!');
        } else {
            const error = await response.json();
            showNotification(error.message || 'Đăng ký thất bại', 'error');
        }
    } catch (error) {
        console.error('Enrollment error:', error);
        showNotification('Đăng ký khóa học thành công!'); // Demo success
    } finally {
        hideLoading();
    }
}

function readBlogPost(postId) {
    // Implement blog post reading functionality
    showNotification('Chức năng đọc bài viết đang được phát triển');
}

// Modal Functions
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

function switchModal(currentModalId, targetModalId) {
    closeModal(currentModalId);
    openModal(targetModalId);
}

// Close modal when clicking outside
window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        e.target.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
});

// Chatbot Functions
function toggleChatbot() {
    const chatbotWindow = document.getElementById('chatbotWindow');
    if (chatbotWindow.style.display === 'flex') {
        chatbotWindow.style.display = 'none';
    } else {
        chatbotWindow.style.display = 'flex';
    }
}

function sendMessage() {
    const input = document.getElementById('chatbotInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    // Add user message
    addMessageToChat(message, 'user');
    input.value = '';
    
    // Simulate bot response
    setTimeout(() => {
        const botResponse = generateBotResponse(message);
        addMessageToChat(botResponse, 'bot');
    }, 1000);
}

function addMessageToChat(message, sender) {
    const messagesContainer = document.getElementById('chatbotMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    messageDiv.innerHTML = `<p>${message}</p>`;
    
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function generateBotResponse(userMessage) {
    const responses = {
        'xin chào': 'Xin chào! Tôi có thể giúp gì cho bạn?',
        'khóa học': 'Chúng tôi có nhiều khóa học về lập trình, thiết kế, marketing. Bạn quan tâm khóa học nào?',
        'giá': 'Giá khóa học từ miễn phí đến 399,000 VNĐ. Chúng tôi cũng có nhiều khóa học miễn phí chất lượng cao.',
        'thanh toán': 'Chúng tôi hỗ trợ thanh toán qua thẻ tín dụng, ví điện tử và chuyển khoản ngân hàng.',
        'chứng chỉ': 'Có, bạn sẽ nhận được chứng chỉ hoàn thành sau khi hoàn thành khóa học.',
        'default': 'Cảm ơn bạn đã liên hệ! Tôi sẽ chuyển câu hỏi của bạn tới đội hỗ trợ.'
    };
    
    const lowerMessage = userMessage.toLowerCase();
    
    for (const key in responses) {
        if (lowerMessage.includes(key)) {
            return responses[key];
        }
    }
    
    return responses.default;
}

// Notification Functions
function showNotification(message, type = 'success') {
    const notification = document.getElementById('notification');
    const notificationText = document.getElementById('notificationText');
    
    notificationText.textContent = message;
    notification.className = `notification ${type}`;
    notification.style.display = 'flex';
    
    setTimeout(() => {
        notification.style.display = 'none';
    }, 3000);
}

// Loading Functions
function showLoading() {
    // Add loading spinner to buttons or show loading overlay
    const buttons = document.querySelectorAll('button[type="submit"]');
    buttons.forEach(btn => {
        btn.classList.add('loading');
        btn.innerHTML = '<span class="spinner"></span>' + btn.innerHTML;
    });
}

function hideLoading() {
    const buttons = document.querySelectorAll('button[type="submit"]');
    buttons.forEach(btn => {
        btn.classList.remove('loading');
        const spinner = btn.querySelector('.spinner');
        if (spinner) {
            spinner.remove();
        }
    });
}

// Scroll Animations
function setupScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
            }
        });
    }, observerOptions);

    // Observe elements for animation
    const animatedElements = document.querySelectorAll('.feature-card, .course-card, .blog-card');
    animatedElements.forEach(el => {
        el.classList.add('animate-on-scroll');
        observer.observe(el);
    });
}

// Smooth Scrolling
function setupSmoothScrolling() {
    const navLinks = document.querySelectorAll('a[href^="#"]');
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            const targetId = link.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                const offsetTop = targetElement.offsetTop - 80; // Account for fixed navbar
                
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                navMenu.classList.remove('active');
            }
        });
    });
}

// Navbar scroll effect
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 100) {
        navbar.style.background = 'rgba(255, 255, 255, 0.98)';
        navbar.style.boxShadow = '0 2px 30px rgba(0, 0, 0, 0.15)';
    } else {
        navbar.style.background = 'rgba(255, 255, 255, 0.95)';
        navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
    }
});

// Performance optimization
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Search functionality (if needed)
function searchCourses(query) {
    const filteredCourses = courses.filter(course => 
        course.title.toLowerCase().includes(query.toLowerCase()) ||
        course.description.toLowerCase().includes(query.toLowerCase()) ||
        course.category.toLowerCase().includes(query.toLowerCase())
    );
    
    renderCourses(filteredCourses);
}
