// Vercel serverless function for blog API
const mysql = require('mysql2/promise');

// Database configuration
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'courseplatform',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  connectTimeout: 60000,
  acquireTimeout: 60000,
  timeout: 60000
};

// Create connection pool
let pool;

async function getPool() {
  if (!pool) {
    pool = mysql.createPool(dbConfig);
  }
  return pool;
}

// Sample blog data (fallback if database is not available)
const sampleBlogs = [
  {
    id: 1,
    title: '10 Xu hướng công nghệ sẽ thay đổi tương lai',
    content: 'Khám phá những xu hướng công nghệ mới nhất sẽ định hình tương lai của chúng ta...',
    excerpt: 'Tìm hiểu về AI, blockchain, IoT và các công nghệ đột phá khác',
    author: 'Tech Expert',
    publishedAt: '2024-01-15',
    category: 'Technology',
    image: 'https://images.unsplash.com/photo-1518186285589-2f7649de83e0?w=400',
    readTime: '5 phút đọc',
    tags: ['AI', 'Blockchain', 'Technology']
  },
  {
    id: 2,
    title: 'Cách học lập trình hiệu quả cho người mới bắt đầu',
    content: 'Hướng dẫn chi tiết các bước học lập trình từ cơ bản đến nâng cao...',
    excerpt: 'Lộ trình học lập trình từ A-Z dành cho người mới',
    author: 'Code Master',
    publishedAt: '2024-01-12',
    category: 'Programming',
    image: 'https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?w=400',
    readTime: '8 phút đọc',
    tags: ['Programming', 'Tutorial', 'Beginner']
  },
  {
    id: 3,
    title: 'Thiết kế UX/UI: Những nguyên tắc cơ bản',
    content: 'Các nguyên tắc thiết kế UX/UI mà mọi designer cần biết...',
    excerpt: 'Nắm vững các nguyên tắc cơ bản trong thiết kế giao diện',
    author: 'Design Pro',
    publishedAt: '2024-01-10',
    category: 'Design',
    image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400',
    readTime: '6 phút đọc',
    tags: ['UX', 'UI', 'Design']
  }
];

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  try {
    const { method, query } = req;
    const { id, category, search, limit = 10, offset = 0 } = query;

    if (method === 'GET') {
      // If requesting specific blog post by ID
      if (id) {
        try {
          const pool = await getPool();
          const [rows] = await pool.execute('SELECT * FROM blog_posts WHERE id = ?', [id]);
          
          if (rows.length > 0) {
            res.status(200).json({
              success: true,
              data: rows[0]
            });
          } else {
            // Fallback to sample data
            const blog = sampleBlogs.find(b => b.id == id);
            if (blog) {
              res.status(200).json({
                success: true,
                data: blog
              });
            } else {
              res.status(404).json({
                success: false,
                message: 'Blog post not found'
              });
            }
          }
        } catch (dbError) {
          console.log('Database error, using sample data:', dbError.message);
          const blog = sampleBlogs.find(b => b.id == id);
          if (blog) {
            res.status(200).json({
              success: true,
              data: blog
            });
          } else {
            res.status(404).json({
              success: false,
              message: 'Blog post not found'
            });
          }
        }
        return;
      }

      // Get all blog posts with filtering
      try {
        const pool = await getPool();
        let query = 'SELECT * FROM blog_posts WHERE 1=1';
        let params = [];

        if (category && category !== 'all') {
          query += ' AND category = ?';
          params.push(category);
        }

        if (search) {
          query += ' AND (title LIKE ? OR content LIKE ?)';
          params.push(`%${search}%`, `%${search}%`);
        }

        query += ' ORDER BY published_at DESC LIMIT ? OFFSET ?';
        params.push(parseInt(limit), parseInt(offset));

        const [rows] = await pool.execute(query, params);
        
        res.status(200).json({
          success: true,
          data: rows,
          total: rows.length
        });
      } catch (dbError) {
        console.log('Database error, using sample data:', dbError.message);
        
        // Filter sample data
        let filteredBlogs = [...sampleBlogs];
        
        if (category && category !== 'all') {
          filteredBlogs = filteredBlogs.filter(blog => blog.category.toLowerCase() === category.toLowerCase());
        }

        if (search) {
          const searchLower = search.toLowerCase();
          filteredBlogs = filteredBlogs.filter(blog => 
            blog.title.toLowerCase().includes(searchLower) || 
            blog.content.toLowerCase().includes(searchLower)
          );
        }

        // Apply pagination
        const startIndex = parseInt(offset);
        const endIndex = startIndex + parseInt(limit);
        const paginatedBlogs = filteredBlogs.slice(startIndex, endIndex);

        res.status(200).json({
          success: true,
          data: paginatedBlogs,
          total: filteredBlogs.length
        });
      }
    } else {
      res.status(405).json({
        success: false,
        message: 'Method not allowed'
      });
    }
  } catch (error) {
    console.error('API Error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
}
